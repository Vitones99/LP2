﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace P0030482021014
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] Contador = new double[4, 4];
            double[] TotalMes = new double[4];
            string valor;
            double TotalMeses = 0;

            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    valor = Interaction.InputBox("Digite o valor da semana " + (y + 1) + "\nDo Mês: " + (x + 1), "Entrada de dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Campo está vazio");
                        y--;
                    }
                    else if (double.TryParse(valor, out Contador[x, y]))
                    {
                        double.TryParse(valor, out Contador[x, y]);
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas números!");
                        y--;
                    }
                }
            }

            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    TotalMes[x] = TotalMes[x] + Contador[x, y];
                }
                TotalMeses = TotalMeses + TotalMes[x];
            }

            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    lboxResultados.Items.Add("Total do Mês: " + (x + 1) + " Semana: " + (y + 1) + ": R$" + Contador[x, y].ToString("N2"));
                }
                lboxResultados.Items.Add(">>Total Mês: R$" + TotalMes[x].ToString("N2"));
                lboxResultados.Items.Add("--------------------------------------------------------------");
            }
            lboxResultados.Items.Add("Total Geral: R$" + TotalMeses.ToString("N2"));
        }

    }
}
